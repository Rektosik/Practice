﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Practice3
{
    public class SettingsForm : Form
    {
        private NumericUpDown layersInput, pointsInput, radiusInput;
        private Button okButton, cancelButton, colorButton, layerColorButton;
        private ColorDialog colorDialog;
        public ExtendedFigureParameters UpdatedParameters { get; private set; }

        public SettingsForm(ExtendedFigureParameters existingParams)
        {
            this.Text = "Фігура - Налаштування";
            this.Width = 300;
            this.Height = 250;

            colorDialog = new ColorDialog();
            UpdatedParameters = new ExtendedFigureParameters
            {
                Layers = existingParams.Layers,
                PointCount = existingParams.PointCount,
                Radius = existingParams.Radius,
                PointColor = existingParams.PointColor,
                LayerColor = existingParams.LayerColor
            };

            Label layersLabel = new Label { Text = "Шари:", Left = 10, Top = 20 };
            layersInput = new NumericUpDown { Left = 130, Top = 20, Width = 100, Minimum = 1, Maximum = 10, Value = existingParams.Layers };

            Label pointsLabel = new Label { Text = "Кількість точок:", Left = 10, Top = 50 };
            pointsInput = new NumericUpDown { Left = 130, Top = 50, Width = 100, Minimum = 3, Maximum = 20, Value = existingParams.PointCount };

            Label radiusLabel = new Label { Text = "Радіус:", Left = 10, Top = 80 };
            radiusInput = new NumericUpDown
            {
                Left = 130,
                Top = 80,
                Width = 100,
                Minimum = 10,
                Maximum = 10000, 
                Value = (decimal)Math.Min(existingParams.Radius, 10000) 
            };

            colorButton = new Button { Text = "Колір точок", Left = 10, Top = 110, Width = 100, BackColor = existingParams.PointColor };
            colorButton.Click += (s, e) =>
            {
                colorDialog.Color = UpdatedParameters.PointColor;
                if (colorDialog.ShowDialog() == DialogResult.OK)
                {
                    UpdatedParameters.PointColor = colorDialog.Color;
                    colorButton.BackColor = colorDialog.Color;
                }
            };

            layerColorButton = new Button { Text = "Колір шарів", Left = 130, Top = 110, Width = 100, BackColor = existingParams.LayerColor };
            layerColorButton.Click += (s, e) =>
            {
                colorDialog.Color = UpdatedParameters.LayerColor;
                if (colorDialog.ShowDialog() == DialogResult.OK)
                {
                    UpdatedParameters.LayerColor = colorDialog.Color;
                    layerColorButton.BackColor = colorDialog.Color;
                }
            };

            okButton = new Button { Text = "OK", DialogResult = DialogResult.OK, Left = 30, Width = 100, Top = 160 };
            cancelButton = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel, Left = 150, Width = 100, Top = 160 };

            Controls.AddRange(new Control[]
            {
                layersLabel, layersInput,
                pointsLabel, pointsInput,
                radiusLabel, radiusInput,
                colorButton, layerColorButton,
                okButton, cancelButton
            });

            AcceptButton = okButton;
            CancelButton = cancelButton;

            this.FormClosing += (s, e) =>
            {
                if (this.DialogResult == DialogResult.OK)
                {
                    UpdatedParameters.Layers = (int)layersInput.Value;
                    UpdatedParameters.PointCount = (int)pointsInput.Value;
                    UpdatedParameters.Radius = (float)radiusInput.Value;
                }
            };
        }
    }
}

