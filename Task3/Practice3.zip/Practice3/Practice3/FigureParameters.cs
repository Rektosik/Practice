﻿using System;
using System.Drawing;

namespace Practice3
{
    public class FigureParameters
    {
        public int Layers { get; set; } = 2;
        public int PointCount { get; set; } = 8;
        public float Radius { get; set; } = 200;
        public Color PointColor { get; set; } = Color.MediumSlateBlue;
    }

    public class ExtendedFigureParameters : FigureParameters
    {
        public Color LayerColor { get; set; } = Color.LightGray;

        public static ExtendedFigureParameters operator *(ExtendedFigureParameters p, float scale)
        {
            return new ExtendedFigureParameters
            {
                Layers = p.Layers,
                PointCount = p.PointCount,
                Radius = p.Radius * scale,
                PointColor = p.PointColor,
                LayerColor = p.LayerColor
            };
        }

        public static ExtendedFigureParameters operator +(ExtendedFigureParameters p, int shift)
        {
            return new ExtendedFigureParameters
            {
                Layers = p.Layers + shift,
                PointCount = p.PointCount,
                Radius = p.Radius,
                PointColor = p.PointColor,
                LayerColor = p.LayerColor
            };
        }

        public static ExtendedFigureParameters operator -(ExtendedFigureParameters p, int shift)
        {
            return new ExtendedFigureParameters
            {
                Layers = Math.Max(1, p.Layers - shift),
                PointCount = p.PointCount,
                Radius = p.Radius,
                PointColor = p.PointColor,
                LayerColor = p.LayerColor
            };
        }

        public static ExtendedFigureParameters operator ++(ExtendedFigureParameters p)
        {
            p.Layers += 1;
            return p;
        }

        public static ExtendedFigureParameters operator --(ExtendedFigureParameters p)
        {
            p.Layers = Math.Max(1, p.Layers - 1);
            return p;
        }
    }
}
