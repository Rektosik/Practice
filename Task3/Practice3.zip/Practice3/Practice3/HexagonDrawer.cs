﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace Practice3
{
    public class HexagonStarDrawer
    {
        public void Draw(Graphics g, FigureParameters p, Rectangle area)
        {
            PointF center = new PointF(area.Width / 2f, area.Height / 2f);
            float radiusStep = p.Radius / p.Layers;
            int count = p.PointCount;

            List<PointF[]> layers = new List<PointF[]>();

            for (int i = 1; i <= p.Layers; i++)
            {
                float r = i * radiusStep;
                var layerPoints = GetPolygonPoints(center, r, count);
                layers.Add(layerPoints);
            }

            Pen layerPen = new Pen(p is ExtendedFigureParameters ep ? ep.LayerColor : Color.LightGray);

            for (int i = 0; i < count; i++)
                for (int j = 0; j < layers.Count - 1; j++)
                    g.DrawLine(Pens.Gray, layers[j][i], layers[j + 1][i]);

            for (int i = 0; i < layers.Count; i++)
                for (int j = i + 1; j < layers.Count; j++)
                    for (int k = 0; k < count; k++)
                        g.DrawLine(layerPen, layers[i][k], layers[j][k]);

            foreach (var layer in layers)
                for (int i = 0; i < count; i++)
                    g.DrawLine(Pens.Black, layer[i], layer[(i + 1) % count]);

            foreach (var layer in layers)
                for (int i = 0; i < count; i++)
                    for (int j = i + 1; j < count; j++)
                        g.DrawLine(Pens.DarkGray, layer[i], layer[j]);

            foreach (var layer in layers)
            {
                foreach (var pt in layer)
                {
                    using (Brush b = new SolidBrush(p.PointColor))
                        g.FillEllipse(b, pt.X - 4, pt.Y - 4, 8, 8);
                }
            }

            g.FillEllipse(Brushes.LightGreen, center.X - 5, center.Y - 5, 10, 10);
            foreach (var pt in layers[0])
                g.DrawLine(Pens.Gray, center, pt);

            layerPen.Dispose();
        }

        private PointF[] GetPolygonPoints(PointF center, float radius, int count)
        {
            var points = new PointF[count];
            for (int i = 0; i < count; i++)
            {
                double angle = i * 2 * Math.PI / count - Math.PI / 2;
                points[i] = new PointF(
                    center.X + (float)(radius * Math.Cos(angle)),
                    center.Y + (float)(radius * Math.Sin(angle))
                );
            }
            return points;
        }
    }
}
