using System;
using System.Drawing;
using System.Windows.Forms;

namespace Practice3
{
    public partial class Form1 : Form
    {
        private ExtendedFigureParameters parameters = new ExtendedFigureParameters();
        private HexagonStarDrawer drawer = new HexagonStarDrawer();

        public Form1()
        {
            InitializeComponent();
            this.Text = "Hexagon Star Viewer";
            this.Width = 600;
            this.Height = 600;

            drawPanel.Paint += drawPanel_Paint;

        }

        private void drawPanel_Paint(object sender, PaintEventArgs e)
        {
            drawer.Draw(e.Graphics, parameters, drawPanel.ClientRectangle);
        }

        private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var settingsForm = new SettingsForm(parameters))
            {
                if (settingsForm.ShowDialog() == DialogResult.OK)
                {
                    parameters = settingsForm.UpdatedParameters;
                    drawPanel.Invalidate();
                    drawPanel.Update();
                }
            }
        }

        private void scaleUpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            parameters = parameters * 1.5f;
            drawPanel.Invalidate();
            drawPanel.Update();
        }

        private void addLayerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            parameters++;
            drawPanel.Invalidate();
            drawPanel.Update();
        }

        private void removeLayerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            parameters--;
            drawPanel.Invalidate();
            drawPanel.Update();
        }
        private void drawToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
